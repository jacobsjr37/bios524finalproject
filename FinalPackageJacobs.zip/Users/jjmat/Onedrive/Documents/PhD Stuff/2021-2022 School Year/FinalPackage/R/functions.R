#' Summarize Function
#'
#' Summarizes the variable in the given dataset.
#' example: summarize_var(creditcard, "reports")
#' @param data_frame the dataset in question.
#' @param var_name the name of the column in the dataset.
#' @return summary statistics of the variable being used.
#' @export
summarize_var <- function(data_frame, var_name) {
  column <- data_frame[,var_name]
  if (is.numeric(column[1])) {
    summary(column)
  }
  else {
    table(column)
  }
}

#' Graph Variables
#'
#' allows the variable within the dataset to be graphed if it is numeric.
#' example: graph_var(creditcard, "reports")
#' @param data_frame the dataset in quesetion.
#' @param var_name the name of the column in the dataset.
#' @return a histogram of the variable.
#' @export
graph_var <- function(data_frame, var_name) {
  column <- data_frame[,var_name]
  if (is.numeric(column[1])) {
    graphics::hist(column, xlab = var_name)
  }
  else {
    print("The variable needs to be numeric.")
  }
}

#' Decision Trees
#'
#' generates a decision tree based on the variables you feed into the
#' function.
#' @param data_frame the dataset in question.
#' @param equation an equation that represents the first argument for the
#' rpart function.
#' example: card ~ reports + age + expenditure
#' @return an rpart object corresponding to the decision tree.
#' @export
make_tree <- function(data_frame, equation) {
  tree <- rpart::rpart(formula = equation, data = data_frame,
                       method = "class")
  return(tree)
}

#' Compute AUC
#'
#' computes the AUC on a 70% training and a 30% validation split of the
#' dataset. note that the split is random each time this function is
#' called.
#' @param data_frame the dataset in question.
#' @param equation an equation that represents the first argument for the
#' rpart function.
#' @return the AUC for the decision tree.
#' @export
compute_AUC <- function(data_frame, equation) {
  #Creating Test and Validation Sets
  index <- sample(nrow(data_frame),nrow(data_frame)*0.70)
  data.train = data_frame[index,]
  data.test = data_frame[-index,]

  # Tree Construction for some variables
  data.rpart <- rpart::rpart(formula = equation, data = data.train,
                      method = "class")

  # Get test probabilities
  card.test.prob <- stats::predict(data.rpart,data.test, type = "prob")

  # Get ROC Curve for tree
  predictor <- ROCR::prediction(card.test.prob[,2], data.test$card)

  # Get AUC
  methods::slot(ROCR::performance(predictor, "auc"), "y.values")[[1]]
}

#' Plot ROC Curve
#'
#' plots the ROC curve for a decision tree corresponding to an equation.
#' @param data_frame the dataset in question.
#' @param equation an equation that represents the first argument in the
#' rpart function.
#' @return a plot of the ROC curve.
#' @export
plot_ROC <- function(data_frame, equation) {
  #Creating Test and Validation Sets
  index <- sample(nrow(data_frame),nrow(data_frame)*0.70)
  data.train = data_frame[index,]
  data.test = data_frame[-index,]

  # Tree Construction for some variables
  data.rpart <- rpart::rpart(formula = equation, data = data.train,
                             method = "class")

  # Get test probabilities
  card.test.prob <- stats::predict(data.rpart,data.test, type = "prob")

  # Get ROC Curve for tree
  predictor <- ROCR::prediction(card.test.prob[,2], data.test$card)
  perf = ROCR::performance(predictor, "tpr", "fpr")
  ROCR::plot(perf)
}

#' Confusion Matrix
#'
#' Prints a Confusion Matrix for a decision tree.
#' @param data_frame the dataset in question.
#' @param equation an equation corresponding to the first argument of the
#' rpart function.
#' @return a confusion matrix for the decision tree.
#' @export
conf_matrix <- function(data_frame, equation) {
  # Tree Construction for some variables
  data.rpart <- rpart::rpart(formula = equation, data = data_frame,
                             method = "class")
  #Confusion matrix
  pred <- stats::predict(data.rpart, type = "class")
  table(data_frame$card, pred, dnn = c("True", "Pred"))
}
